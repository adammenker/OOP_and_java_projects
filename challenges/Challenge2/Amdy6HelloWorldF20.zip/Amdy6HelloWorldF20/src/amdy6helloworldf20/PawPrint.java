/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amdy6helloworldf20;

/**
 *
 * @author adammenker
 */
public class PawPrint {
    
    public String myPawPrint;
    
    public void printPawPrint(String myPawPrint){
        // this.myPawPrint = "amdy6";
        System.out.println("My PawPrint is \"" + myPawPrint + "\"");
    }
    
}
