/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amdy6languagebasicsf20;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;

/**
 *
 * @author adammenker
 */
public class Amdy6LanguageBasicsF20 {

    /**
     * @param args the command line arguments
     */
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        char c1 = 'a';
        char c2 = 97;
        short qualityScore = 89;
        int months = 12;
        float miles = 1023.5f;
        float days = 365f;
        boolean sunny = true;
        boolean warm = false;
        
        // I used https://studyfied.com/tutorial/java/date-time/localtime/ to figure out how to access and find the system clocks local hour and time
        // I used https://docs.oracle.com/javase/8/docs/api/java/time/LocalTime.html#getHour-- to discover the methods for getting the hour and minute
        LocalTime localTime = LocalTime.now();
        int hour = localTime.getHour();
        int minute = localTime.getMinute();
        
        // I used https://www.javatpoint.com/how-to-generate-random-number-in-java to discover how to generate a random number
        // I interpretted and implemented 0.0 - 4.0 to be any number between these two values, not just a number to the tenths place
        double grade = Math.random() * 4;
        
        String greeting = "Hello";
        String myPawPrint = "amdy6";
        
        
        compareChars(c1, c2);
        checkQualityScore(qualityScore);
        
        float dcm = ((months * miles) / days);
        // I chose to use a method
        getDcm(dcm);
        
        getTodaysPlan(sunny, warm);
        getTheCurrentTimeOfDay(hour, minute);
        getGPA(grade);
        forCount();
        whileCountDown();
        invokeMe(greeting, myPawPrint);
    }
    
    static void compareChars(char a, char b) {
        if(a == b){
            System.out.printf("%c and %c are the same\n", a, b);
        } else {
            System.out.printf("%c and %c are NOT the same\n", a, b);
        }
    }
    
    static void checkQualityScore(int qualityScore){
        if(qualityScore >= 0 && qualityScore <= 75){
            System.out.printf("The quality is bad.\n");
        } else{
            System.out.print("Good quality.\n");
        }
    }
    
    static void getDcm(float dcm) {
        System.out.printf("My average daily car mileage = %.2f\n", dcm);
    }
    
    static void getTodaysPlan(boolean sunny, boolean warm){
        if(sunny == true && warm == true){
            System.out.printf("Go swimming at beach.\n");
        } else if(sunny == false && warm == true){
            System.out.printf("Go for a drive.\n");
        } else {
            System.out.printf("Stay home and code.\n");
        }
    }
    
    static void getTheCurrentTimeOfDay(int hour, int minute){
        String timePeriod = "";
        if(hour >= 5 && hour <= 10){
            timePeriod = "MORNING";
        } else if(hour >= 11 && hour <= 16){
            timePeriod = "AFTERNOON";
        } else if(hour >= 17 && hour <= 22){
            timePeriod = "EVENING";
        } else if(hour >= 23 && hour <= 4){
            timePeriod = "NIGHT";
        }
        
        String minuteWithZero = "";
        if(minute < 10){
            minuteWithZero = "0" + minute;
        } else {
            minuteWithZero = "" + minute;
        }
        
        int hourWithConversion;
        hourWithConversion = hour % 12;
        
        String timeString;
        switch (timePeriod) {
            case ("MORNING"): 
                    timeString = ("The current time is " + hourWithConversion + ":" + minuteWithZero + " in the MORNING.\n");
                    break;
            case ("AFTERNOON"): 
                    timeString = ("The current time is " + hourWithConversion + ":" + minuteWithZero + " in the AFTERNOON.\n");
                    break; 
            case ("EVENING"): 
                    timeString = ("The current time is " + hourWithConversion + ":" + minuteWithZero + " in the EVENING.\n");
                    break; 
            case ("NIGHT"): 
                    timeString = ("The current time is " + hourWithConversion + ":" + minuteWithZero + " in the NIGHT.\n");
                    break;        
            default: timeString = "You have the wrong time.\n";
                     break;
        }
        System.out.printf(timeString);
    }
    
    static void getGPA(double grade) {
        
        String message = "";
        if(grade < 0.69){
            message = "The student’s GPA grade is an F in the class.";
        } else if(grade >= 0.70 && grade <= 0.99){
            message = "The student’s GPA grade is an D- in the class.";
        } else if(grade >= 1.00 && grade <= 1.29){
            message = "The student’s GPA grade is an D in the class.";
        } else if(grade >= 1.30 && grade <= 1.69){
            message = "The student’s GPA grade is an D+ in the class.";
        } else if(grade >= 1.70 && grade <= 1.99){
            message = "The student’s GPA grade is an C- in the class.";
        } else if(grade >= 2.00 && grade <= 2.29){
            message = "The student’s GPA grade is an C in the class.";
        } else if(grade >= 2.30 && grade <= 2.69){
            message = "The student’s GPA grade is an C+ in the class.";
        } else if(grade >= 2.70 && grade <= 2.99){
            message = "The student’s GPA grade is an B- in the class.";
        } else if(grade >= 3.00 && grade <= 3.29){
            message = "The student’s GPA grade is an B in the class.";
        } else if(grade >= 3.30 && grade <= 3.69){
            message = "The student’s GPA grade is an B+ in the class.";
        } else if(grade >= 3.70 && grade <= 3.99){
            message = "The student’s GPA grade is an A- in the class.";
        } else if(grade == 4.00){
            message = "The student’s GPA grade is an A in the class.";
        } else if(grade >= 4.00){
            message = "The student’s GPA grade is an A+ in the class.";
        }
        // System.out.printf("%f\n", grade);
        System.out.printf(message + "\n");
    }
    
    static void forCount(){
        for(int count = 9; count > 3; count--){
            if(count % 2 == 0){
                System.out.printf("%d\n", count);
            }
        }
    }
    
    static void whileCountDown(){
        int countDown = 3;
        while(countDown > 0){
            System.out.println(countDown);
            countDown--;
        }
        System.out.println("Houston, we have a lift off!");
    }
    
    // I used https://beginnersbook.com/2017/10/java-display-time-in-12-hour-format-with-ampm/ and used some code from here
    // I copied and pasted from my challenge 2
    static void invokeMe(String greeting, String pawPrint){          
        
        DateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy hh:mmaa");
    	String dateString2 = dateFormat2.format(new Date());
        
        System.out.println(greeting + ", my pawprint is " + pawPrint + " and Today's date is " + dateString2);
    }
}
